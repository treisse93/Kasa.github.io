import Datas from './housing.json';

export default Datas